from cmu_112_graphics import *
import cv2

import math
def appStarted(app):
    app.mode = 'loadImage'
    app.rows, app.cols = 80,80
    app.highlight = False
    app.position, app.lines, app.palm, app.finger = [], [],[],[]
    app.type, app.pic  ='',''
    app.imageHeight,app.imageWidth = 0,0
    app.visibilityA, app.visibilityB, app.visibilityC =1,1,1
    app.color = 'lightgreen'
    app.c1, app.c2, app.c3 = app.color,'red',app.color
    app.intensity = 'ave' #by default if user does not select
    app.heartRes, app.lifeRes, app.headRes, app.luckRes, app.typeRes ='', '', '', '', ''
    app.lifeNum = 1
    app.proceed,app.bonusReading = False, False
    app.showError, app.chosed1, app.chosed2 =False, False, False
    app.timerDelay, app.count = 330, 1

#All keyPressed functions
def loadImage_keyPressed(app, event):
    "press t to open webcam for new image"
    if event.key == 'p':
        app.mode = "between"

def between_keyPressed(app, event):
    if event.key == 'c':
        takePic(app)
        app.mode = "applyGrid"

def applyGrid_keyPressed(app, event):
    if event.key == 'r':
        app.highlight = False
        app.position = []
    if event.key == 'a': return appStarted(app)

def palmHeight_keyPressed(app, event):
    if event.key == 'a': return appStarted(app)
    if event.key == 'r':
        app.highlight = False
        app.position = []

def luckLine_keyPressed(app, event):
    if event.key == 'a': return appStarted(app)
    if event.key == 'r':
        app.highlight = False
        app.position = []

def heartLine_keyPressed(app, event):
    if event.key == 'a': return appStarted(app)
    if event.key == 'r':
        app.highlight = False
        app.position = []

def headLine_keyPressed(app, event):
    if event.key == 'a': return appStarted(app)
    if event.key == 'r':
        app.highlight = False
        app.position = []

def upperEdge_keyPressed(app, event):
    if event.key == 'a': return appStarted(app)
    if event.key == 'r':
        app.highlight = False
        app.position = []

def crossLine_keyPressed(app,event):
    if event.key == 'a': return appStarted(app)
    if event.key == 'r':
        app.highlight = False
        app.position = []

def lifeLine_keyPressed(app, event):
    if event.key == 'a': return appStarted(app)
    if event.key == 'r':
        app.highlight = False
        app.position = []
    if event.key == 'y' or event.key == 'Y': 
        app.chosed1 = True
        app.chosed2 = not app.chosed1
        app.lifeNum = 2
    if event.key == "n" or event.key== 'N':
        app.chosed2 = True
        app.chosed1 = not app.chosed2
        app.lifeNum = 1


#All mousePressed Functions
def applyGrid_mousePressed(app,event):
    x, y = event.x, event.y
    if pointInGrid(app, x,y):
        app.highlight = True
        row, col = getCell(app,x,y)
        app.position.append([row,col])
    if continueSelected(app,x,y):
        if len(app.position)<2: 
            app.showError = True
        else:
            app.showError = False
            palmWidth = lines(app.position, app.intensity)
            app.palm.append(palmWidth)
            app.highlight = False
            app.position = []
            app.intensity = 'ave'
            app.visibilityA,app.visibilityB, app.visibilityC = 1,1,1
            app.mode = "palmHeight"

def palmHeight_mousePressed(app, event):
    x, y = event.x, event.y
    if pointInGrid(app, x,y):
        app.highlight = True
        row, col = getCell(app,x,y)
        app.position.append([row,col])
    if continueSelected(app,x,y):
        if len(app.position)<2: 
            app.showError = True
        else:
            app.showError = False
            palmHeight = lines(app.position, app.intensity)
            app.palm.append(palmHeight)
            app.highlight = False
            app.position = []
            app.intensity = 'ave'
            app.visibilityA,app.visibilityB, app.visibilityC = 1,1,1
            app.mode = "fingerLen"

def fingerLen_mousePressed(app, event):
    x, y = event.x, event.y
    if pointInGrid(app, x,y):
        app.highlight = True
        row, col = getCell(app,x,y)
        app.position.append([row,col])
    if continueSelected(app,x,y):
        if len(app.position)<2: 
            app.showError = True
        else:
            app.showError = False
            app.showError = False
            fingerLen = lines(app.position, app.intensity)
            app.finger.append(fingerLen)
            app.highlight = False
            app.position = []
            app.intensity = 'ave'
            app.visibilityA,app.visibilityB, app.visibilityC = 1,3,1
            app.mode = "heartLine"

def heartLine_mousePressed(app, event):
    x, y = event.x, event.y
    if pointInGrid(app, x,y):
        app.highlight = True
        row, col = getCell(app,x,y)
        app.position.append([row,col])
    if colorSelected1(app, x,y):
        update1(app)
    if colorSelected2(app, x,y):
        update2(app)
    if colorSelected3(app, x,y):
        update3(app)
    if continueSelected(app,x,y):
        if len(app.position)<2: 
            app.showError = True
        else:
            app.showError = False
            heartLine = lines(app.position, app.intensity)
            app.lines.append(heartLine)
            app.highlight = False
            app.position = []
            app.intensity = 'ave'
            app.visibilityA,app.visibilityB, app.visibilityC = 1,3,1
            app.mode = "headLine"

def headLine_mousePressed(app, event):
    x, y = event.x, event.y
    if pointInGrid(app, x,y):
        app.highlight = True
        row, col = getCell(app,x,y)
        app.position.append([row,col])
    if colorSelected1(app, x,y):
        update1(app)
    if colorSelected2(app, x,y):
        update2(app)
    if colorSelected3(app, x,y):
        update3(app)
    if continueSelected(app,x,y):
        if len(app.position)<2: 
            app.showError = True
        else:
            app.showError = False
            headLine = lines(app.position, app.intensity)
            app.lines.append(headLine)
            app.highlight = False
            app.position = []
            app.intensity = 'ave'
            app.visibilityA,app.visibilityB, app.visibilityC = 1,3,1
            app.mode = "luckLine"

def luckLine_mousePressed(app, event):
    x, y = event.x, event.y
    if pointInGrid(app, x,y):
        app.highlight = True
        row, col = getCell(app,x,y)
        app.position.append([row,col])
    if colorSelected1(app, x,y):
        update1(app)
    if colorSelected2(app, x,y):
        update2(app)
    if colorSelected3(app, x,y):
        update3(app)
    if continueSelected(app,x,y):
        if len(app.position)<2: 
            app.showError = True
        else:
            app.showError = False
            luckLine = lines(app.position, app.intensity)
            app.lines.append(luckLine)
            app.highlight = False
            app.position = []
            app.intensity = 'ave'
            app.visibilityA,app.visibilityB, app.visibilityC = 1,3,1
            app.mode = "lifeLine"

def lifeLine_mousePressed(app, event):
    x, y = event.x, event.y
    if pointInGrid(app, x,y):
        app.highlight = True
        row, col = getCell(app,x,y)
        app.position.append([row,col])
    if colorSelected1(app, x,y):
        update1(app)
    if colorSelected2(app, x,y):
        update2(app)
    if colorSelected3(app, x,y):
        update3(app)
    if continueSelected(app,x,y):
        if len(app.position)<2: 
            app.showError = True
            return
        else:
            app.showError = False
            lifeLine = lines(app.position, app.intensity)
            app.lines.append(lifeLine)
            app.highlight = False
            app.position = []
            app.intensity = 'ave'
            app.visibilityA,app.visibilityB, app.visibilityC = 1,3,1
            app.mode = "upperEdge"

def upperEdge_mousePressed(app, event):
    x, y = event.x, event.y
    if pointInGrid(app, x,y):
        app.highlight = True
        row, col = getCell(app,x,y)
        app.position.append([row,col])
    if colorSelected1(app, x,y):
        update1(app)
    if colorSelected2(app, x,y):
        update2(app)
    if colorSelected3(app, x,y):
        update(3)
    if continueSelected(app,x,y):
        if len(app.position)<2: 
            app.showError = True
        else:
            app.showError = False
            palmEdge = lines(app.position, app.intensity)
            app.palm.append(palmEdge)
            app.highlight = False
            app.position = []
            app.intensity = 'ave'
            app.visibilityA,app.visibilityB, app.visibilityC = 1,1,1
            app.mode = "crossLine"
            app.load = True

def crossLine_mousePressed(app, event):
    x, y = event.x, event.y
    if pointInGrid(app, x,y):
        app.highlight = True
        row, col = getCell(app,x,y)
        app.position.append([row,col])
    if colorSelected1(app, x,y):
        update1(app)
    if colorSelected2(app, x,y):
        update2(app)
    if colorSelected3(app, x,y):
        update(3)
    if continueSelected(app,x,y):
        app.showError = False
        crossLine = lines(app.position, app.intensity)
        app.lines.append(crossLine)
        app.highlight = False
        app.position = []
        app.intensity = 'ave'
        app.visibilityA,app.visibilityB, app.visibilityC = 1,1,1
        app.mode = "processData"
        app.load = True


def processData_redrawAll(app, canvas):
    if app.load == True:
        canvas.create_text(app.width/2, app.height/2, text =f"Reading Your Hand! Loading Results..{app.count}", anchor = "center", fill = "Blue", font = 'Helvetica 16 bold')
    if app.proceed == True:
        canvas.create_rectangle(app.width/2-80, app.height/2-30, app.width/2+80, app.height/2+30, fill ="lightgreen", outline ='lightgreen')
        canvas.create_text(app.width/2, app.height/2, text = "Reveal", font = 'Helvetica 12 bold', fill = 'red', anchor = "center")

def processData_timerFired(app):
    app.timerDelay -=20
    app.count+=1
    if app.timerDelay <=50:
        app.proceed = True
        app.load = False

def processData_mousePressed(app, event):
    x, y = event.x, event.y
    if (app.width/2-80<=x<=app.width/2+80) and (app.height/2-30<=y<=app.height/2+30):
        processType(app)
        processLifeLine(app)
        proccessHeadLine(app)
        processHeartLine(app)
        processLuckLine(app)
        app.mode = 'result'

def processData_keyPressed(app, event):
    if event.key == 'a': return appStarted(app)
    
def result_keyPressed(app,event):
    if event.key == 'a': return appStarted(app)

#to click a new pic of hand
def takePic(app):
    #opens webcam
    #Here 0 is first detected camera, 1 is second, so on
    #Number could be required to change depending on camera prefered
    try:cap = cv2.VideoCapture(1) #front camera for my compt
    except:cap = cv2.VideoCapture(0)#back camera

    while cap.isOpened(): 
        ret, frame = cap.read()
        # Show image 
        cv2.imshow('Press Q to Take picture', frame)
        # Checks whether 'q' has been hit and stops the loop
        if cv2.waitKey(1) & 0xFF == ord('q'): 
            app.pic = cv2.imwrite('webcamphoto.jpg', frame)
            new= ImageTk.PhotoImage(Image.open('webcamphoto.jpg')) 
            app.imageHeight = new.height()
            app.imageWidth = new.width()
            cv2.destroyAllWindows()
            #closes loop
            cap.release()

#redrawAll functions
def loadImage_redrawAll(app,canvas):
    new= ImageTk.PhotoImage(Image.open('splashscreen.jpg')) 
    canvas.create_image(app.width//2, app.height//2, image=new, anchor= 'center')
    
def between_redrawAll(app, canvas):
    drawInstructions(app, canvas)
    canvas.create_text(app.width/2, app.height/2, text ="Press 'c' to continue...", 
        anchor = 'center', font = 'Helvetica 20 bold', fill= 'blue')

def drawInstructions(app, canvas):
    canvas. create_text(app.width/2, 200, text = "Helpful Instructions to note:\n"
        "1. You will be asked to take a picture of your palm. The left palm or the right is your preference.\n"
        "2. Make sure your finger and full palm sight is within the camera's frame, for better reading.\n"
        "3. Next is to annotate. When grids appear, click over your palm lines, referencing images on the right.\n"
        "4. If you want to redo your annotation for a line, press 'r'. If you want to restart the whole process, press 'a'.\n"
        "5. You must select at least two grids to proceed, except when annotating the presence of cross lines at the end.\n"
        "6. The more precise and accurate you are in annotating the grids, the better results! But it can get tedious!\n"
        "7. Remember to choose your line intensity from the options below your palm image.\n"
        "8. Click 'continue' to proceed on.", font = "Helvetica 16 bold", width = app.width-20)


def applyGrid_redrawAll(app, canvas):
    new= ImageTk.PhotoImage(Image.open('webcamphoto.jpg')) 
    canvas.create_image(app.width/2, app.height/2, image=new, anchor= 'e')
    drawGrid(app, canvas)
    infoPic=ImageTk.PhotoImage(Image.open('firstdot.jpg')) 
    canvas.create_image(app.width/2+100, app.height/2, image=infoPic, anchor= 'w')
    canvas.create_text(app.width/2, 50, text ="Annotate Your Palm Width", anchor = "center", font = 'Arial 14 bold',fill ='blue')
    drawDoneButton(app, canvas)
    if app.highlight == True:
        hightCell(app, canvas)
    if app.showError == True:
        drawErrorMessage(app, canvas)

def palmHeight_redrawAll(app, canvas):
    new= ImageTk.PhotoImage(Image.open('webcamphoto.jpg')) 
    canvas.create_image(app.width/2, app.height/2, image=new, anchor= 'e')
    canvas.create_text(app.width/2, 50, text ="Annotate Palm's Height", 
        anchor = "center", font = 'Arial 14 bold',fill ='blue')
    infoPic=ImageTk.PhotoImage(Image.open('palmheight.jpg')) 
    canvas.create_image(app.width/2+100, app.height/2, image=infoPic, anchor= 'w')
    drawGrid(app, canvas)
    drawDoneButton(app, canvas)
    if app.highlight == True:
        hightCell(app, canvas)
    if app.showError == True:
        drawErrorMessage(app, canvas)
    
def fingerLen_redrawAll(app, canvas):
    new= ImageTk.PhotoImage(Image.open('webcamphoto.jpg')) 
    canvas.create_image(app.width/2, app.height/2, image=new, anchor= 'e')
    canvas.create_text(app.width/2, 50, text ="Annotate Your Longest Finger", 
        anchor = "center", font = 'Arial 14 bold',fill ='blue')
    infoPic=ImageTk.PhotoImage(Image.open('fingerlen.jpg')) 
    canvas.create_image(app.width/2+100, app.height/2, image=infoPic, anchor= 'w')
    drawGrid(app, canvas)
    drawDoneButton(app, canvas)
    if app.highlight == True:
        hightCell(app, canvas)
    if app.showError == True:
        drawErrorMessage(app, canvas)

def heartLine_redrawAll(app, canvas):
    new= ImageTk.PhotoImage(Image.open('webcamphoto.jpg')) 
    canvas.create_image(app.width//2, app.height//2, image=new, anchor= 'e')
    canvas.create_text(app.width/2, 50, text ="Annotate Your Heart Line", 
        anchor = "center", font = 'Arial 14 bold',fill ='blue')
    infoPic=ImageTk.PhotoImage(Image.open('heartline.jpg')) 
    canvas.create_image(app.width/2+100, app.height/2, image=infoPic, anchor= 'w')
    drawGrid(app, canvas)
    drawDoneButton(app, canvas)
    drawVisibiltyScale(app, canvas)
    if app.highlight == True:
        hightCell(app, canvas)
    if app.showError == True:
        drawErrorMessage(app, canvas)

def headLine_redrawAll(app, canvas):
    new= ImageTk.PhotoImage(Image.open('webcamphoto.jpg')) 
    canvas.create_image(app.width/2, app.height/2, image=new, anchor= 'e')
    canvas.create_text(app.width/2, 50, text ="Annotate Your Head Line", 
        anchor = "center", font = 'Arial 14 bold',fill ='red')
    infoPic=ImageTk.PhotoImage(Image.open('headline.jpg')) 
    canvas.create_image(app.width/2+100, app.height/2, image=infoPic, anchor= 'w')
    drawGrid(app, canvas)
    drawDoneButton(app, canvas)
    drawVisibiltyScale(app, canvas)
    if app.highlight == True:
        hightCell(app, canvas)
    if app.showError == True:
        drawErrorMessage(app, canvas)
    

def lifeLine_redrawAll(app, canvas):
    new= ImageTk.PhotoImage(Image.open('webcamphoto.jpg')) 
    canvas.create_image(app.width/2, app.height/2, image=new, anchor= 'e')
    canvas.create_text(app.width/2, 50, text ="Annotate Your Life Line", 
        anchor = "center", font = 'Arial 14 bold',fill ='blue')
    x = (app.width/2)-app.imageWidth +100
    y = (app.height/2)-(app.imageHeight/2)-100
    if app.chosed1 == False and app.chosed2 == False and app.showError == False:
        canvas.create_text(x, y, text = "Do you have more than 1 life line?", anchor = 'center', font = "Helvetica 12 bold")
        canvas.create_text(x+150, y, text = "Press 'Y/y' or 'N/n'", anchor = 'w', font= "Helvetica 12 bold")
    if app.chosed1 == True and app.chosed2 == False and app.showError == False:
        canvas.create_text(x, y, text = "Life Lines more than 1, recorded!", anchor = 'center',font = "Helvetiva 12 bold")
    if app.chosed2 == True and app.chosed1 == False and app.showError == False:
        canvas.create_text(x, y, text = "Recorded!", anchor = 'center',font = "Helvetiva 12 bold")
    infoPic=ImageTk.PhotoImage(Image.open('lifeline.jpg')) 
    canvas.create_image(app.width/2+100, app.height/2, image=infoPic, anchor= 'w')
    drawGrid(app, canvas)
    drawDoneButton(app, canvas)
    drawVisibiltyScale(app, canvas)
    if app.highlight == True:
        hightCell(app, canvas)
    if app.showError == True:
        drawErrorMessage(app, canvas)

def luckLine_redrawAll(app, canvas):
    new= ImageTk.PhotoImage(Image.open('webcamphoto.jpg')) 
    canvas.create_image(app.width/2, app.height/2, image=new, anchor= 'e')
    canvas.create_text(app.width/2, 50, text ="Annotate Your Luck Line", 
        anchor = "center", font = 'Arial 14 bold',fill ='blue')
    infoPic=ImageTk.PhotoImage(Image.open('luckline.jpg')) 
    canvas.create_image(app.width/2+100, app.height/2, image=infoPic, anchor= 'w')
    drawGrid(app, canvas)
    drawDoneButton(app, canvas)
    drawVisibiltyScale(app, canvas)
    if app.highlight == True:
        hightCell(app, canvas)
    if app.showError == True:
        drawErrorMessage(app, canvas)
    
def upperEdge_redrawAll(app, canvas):
    new= ImageTk.PhotoImage(Image.open('webcamphoto.jpg')) 
    canvas.create_image(app.width/2, app.height/2, image=new, anchor= 'e')
    canvas.create_text(app.width/2, 50, text ="Annotate top Edge Palm Line", 
        anchor = "center", font = 'Arial 14 bold',fill ='blue')
    infoPic=ImageTk.PhotoImage(Image.open('upperedge.jpg')) 
    canvas.create_image(app.width/2+100, app.height/2, image=infoPic, anchor= 'w')
    drawGrid(app, canvas)
    drawDoneButton(app, canvas)
    if app.highlight == True:
        hightCell(app, canvas)
    if app.showError == True:
        drawErrorMessage(app, canvas)

def crossLine_redrawAll(app,canvas):
    new= ImageTk.PhotoImage(Image.open('webcamphoto.jpg')) 
    canvas.create_image(app.width/2, app.height/2, image=new, anchor= 'e')
    canvas.create_text(app.width/2, 50, text ="Annotate Cross in life Line", 
        anchor = "center", font = 'Arial 14 bold',fill ='blue')
    infoPic=ImageTk.PhotoImage(Image.open('crosslines.jpg')) 
    canvas.create_image(app.width/2+100, app.height/2, image=infoPic, anchor= 'w')
    drawGrid(app, canvas)
    drawDoneButton(app, canvas)
    if app.highlight == True:
        hightCell(app, canvas)
    if app.showError == True:
        drawErrorMessage(app, canvas)

def result_redrawAll(app, canvas):
    x = app.width/2+20
    y = app.height/4 +20
    # x, y = (app.width/2)-app.imageWidth +300, (app.height/2)-(app.imageHeight/2)-100
    canvas.create_text(x,y, text = f' You are of type {app.type}. That means {app.typeRes} Your heart line depicts {app.heartRes} Coming to your luck line, {app.luckRes} From reading your headline, {app.headRes} Now as per your life line, {app.lifeRes}'
                    ,anchor = "center", font = 'Times 18 bold', width = app.width-30)
    canvas.create_text(app.width/2, app.height/2, text ="Press 'a' to Restart and get your reading again", 
        anchor = 'center', font = 'Helvetica 20 bold', fill= 'red')

def drawDoneButton(app, canvas):
    x = app.width-app.width/4
    y = app.height-app.height/10
    canvas.create_rectangle(x-80, y-30, x+80, y+30, fill ="lightgreen", outline = "light yellow") 
    canvas.create_text(x, y, text = 'Continue', anchor = 'center',font = 'Arial 12 bold', fill = 'red')

def drawVisibiltyScale(app, canvas):
    x1 = app.width/2-app.imageWidth
    y1 =app.height-app.height/10
    x4 = x1+app.imageWidth
    wildCard = (abs(x1-x4)/3)
    x2 = x1+wildCard
    x3 = x2+wildCard
    center1x = (x1+x2)//2
    center2x = (x2+x3)//2
    center3x = (x3+x4)//2 
    centery = ((y1-50)+(y1+30))//2
    canvas.create_rectangle(x1, y1-50, x2-5, y1+30, fill = app.color, 
        width = app.visibilityA, outline = app.c1)
    canvas.create_rectangle(x2+5, y1-50, x3-5, y1+30, fill = app.color,
        width = app.visibilityB, outline = app.c2)
    canvas.create_rectangle(x3+5, y1-50, x4, y1+30, fill = app.color,
        width = app.visibilityC, outline = app.c3)
    canvas.create_text(center1x, centery, text ="Dark Visible Lines", anchor = "center")
    canvas.create_text(center2x, centery, text ="Moderate Visible Lines", anchor = "center")
    canvas.create_text(center3x, centery, text ="Slightly Visible Lines", anchor = "center")

def colorBarhelper(app):
    #provides cordinates of the color bar
    x1 = app.width/2-app.imageWidth
    y1 =app.height-app.height//10
    x4 = x1+app.imageWidth
    wildCard = (abs(x1-x4)//3)
    x2 = x1+wildCard
    x3 = x2+wildCard
    y2, y3 = y1-50, y1+50
    return x1,x2,x3,x4,y1,y2

def colorSelected1(app, x,y):
    x1,x2,x3,x4,y1,y2 = colorBarhelper(app)
    if (x1<=x<x2) and (y1-50<=y<=y1+30): return True  
    else:return False

def colorSelected2(app, x,y):
    x1,x2,x3,x4,y1,y2 = colorBarhelper(app)
    if (x2<=x<x3) and (y1-50<=y<=y1+30): return True  
    else: return False

def colorSelected3(app, x,y):
    x1,x2,x3,x4,y1,y2 = colorBarhelper(app)
    if (x3<=x<=x4) and (y1-50<=y<=y1+30): return True   
    else: return False

def drawErrorMessage(app, canvas):
    x = (app.width/2)-app.imageWidth +100
    y = (app.height/2)-(app.imageHeight/2)-100
    canvas.create_text(x, y, text = "At least two cells must be selected to proceed!", fill = 'red', font = 'Helvetica 16 bold', anchor = 'w')

def drawGrid(app, canvas):
    # draw grid of cells
    for row in range(app.rows):
        for col in range(app.cols):
            (x0, y0, x1, y1) = getCellBounds(app, row, col)
            canvas.create_rectangle(x0, y0, x1, y1, fill='', 
                outline = 'red', width = 1)

def continueSelected(app,x,y):
    cx, cy = (app.width-(app.width/4)), (app.height-(app.height/10))
    x1, y1, x2, y2 = cx-80, cy-30, cx+80, cy+30  
    if (x1<=x<=x2) and (y1<=y<=y2): return True
    else: return False

#Modified from course notes
def pointInGrid(app, x, y):
    leftMarginX = (app.width/2)-app.imageWidth
    rightMarginX = leftMarginX +app.imageWidth
    leftMarginY = (app.height/2)-(app.imageHeight/2)
    rightMarginY = leftMarginY+app.imageHeight
    return ((leftMarginX <= x <rightMarginX) and
            (leftMarginY <= y <= rightMarginY))

#Modified from course notes
def getCell(app, x, y):
    if (not pointInGrid(app, x, y)):
        return (-1, -1)
    gridWidth  = app.imageWidth 
    gridHeight = app.imageHeight
    cellWidth  = gridWidth / app.cols
    cellHeight = gridHeight / app.rows
    row = int((y- (app.height/2-app.imageHeight/2)) / cellHeight)
    col = int((x-(app.width/2-app.imageWidth)) / cellWidth)
    return (row, col)

def getCellBounds(app, row, col): #modified from course notes
    gridWidth  = app.imageWidth
    gridHeight = app.imageHeight
    cellWidth = gridWidth / app.cols
    cellHeight = gridHeight / app.rows
    x0 = app.width/2-app.imageWidth + col * cellWidth
    x1 = app.width/2-app.imageWidth + (col+1) * cellWidth
    y0 = app.height/2-app.imageHeight/2 + row * cellHeight
    y1 = app.height/2-app.imageHeight/2 + (row+1) * cellHeight
    return x0,y0, x1,y1

def hightCell(app, canvas):
    for i in app.position:
        x0,y1, x2, y2 = getCellBounds(app, i[0], i[1])
        canvas.create_rectangle(x0, y1, x2, y2, fill = '', outline = "Yellow")

def distance(x1, y1, x2,y2):
    return math.sqrt(((x2-x1)**2)+(y2-y1)**2)

def update1(app):
    app.visibilityA,app.visibilityB, app.visibilityC = 3,1,1
    app.c1, app.c2, app.c3 = 'red', 'lightgreen', 'lightgreen'
    app.intensity = "dark"

def update2(app):
    app.visibilityA,app.visibilityB, app.visibilityC = 1,3,1
    app.c1, app.c2, app.c3 = 'lightgreen','red', 'lightgreen'
    app.intensity = "ave"

def update3(app):
    app.visibilityA,app.visibilityB, app.visibilityC = 1,1,3
    app.c1, app.c2, app.c3 = 'lightgreen', 'lightgreen', 'red'
    app.intensity = "light"

class lines:
    def __init__(self, cordList, intensity):
        self.cordList = cordList
        self.intensity = intensity
        
    def length(self):
        if self.cordList ==[]:return 0
        xList, yList = [], []
        for i in self.cordList:
            xList.append(i[0])
            yList.append(i[1])
        startX, startY,  = xList[0], yList[0]
        endX, endY = xList[len(xList)-1], yList[len(yList)-1]
        highestY, lowestY = max(yList), min(yList)
        highestX, lowestX = max(xList), min(yList)
        length = distance(startX, startY, endX,endY)
        return length

#back-end devination Algorithm
# for reading outcome, a not so trustworthy source:www.yourchineseastrology.com
def processHandShape(app): 
    #the width of palm
    palmWidth = app.palm[0].length()
    #the height of palm
    palmHeight = app.palm[1].length()
    finger = app.finger[0]
    if 0<=abs(palmWidth-palmHeight)<=5: 
        palmShape = "square"
    elif (palmHeight>palmWidth) or(palmWidth>palmHeight) and abs(palmWidth-palmHeight)>5: 
        palmShape = "rec"
    else: palmShape = 'sqaure'
    finger = app.finger[0]
    fingerLength = finger.length()
    #rec palm and short fingers: fire
    if palmShape == 'rec' and fingerLength<palmHeight: app.type = "fire"
    #square and short fingers: earth
    elif palmShape == 'sqaure' and fingerLength<palmHeight: app.type = "earth"
    #rec and long fingers: water
    elif palmShape == "rec" and fingerLength>=palmHeight: app.type = "water"
    #square and long fingers: air
    elif palmShape == "square" and fingerLength>=palmHeight: app.type = "air"
    else:app.type = "complex"
    return app.type

def processHeartLine(app):
    heartLine = app.lines[0]
    edgeLine = app.palm[2]
    palmWidth = app.palm[0]
    medium = (palmWidth.length()/2)-2<=heartLine.length()<=(palmWidth.length()/2)+2
    lon = heartLine.length()> ((palmWidth.length()/2)+2)
    short = heartLine.length()<(palmWidth.length()/2)-2
    # long heart line
    if lon: 
        app.heartRes += "you can be too straightforward, and would rather break than bend. "
        app.heartRes += "In career, you could get success although you undergo a lot of hardships. "
    #medium length
    if medium:
        app.heartRes += "you are resourceful. " 
    #short heart line :(
    if short:
        app.heartRes += "you tend to be self-centered, and act arbitrarily without thinking about the consequences. "
    for index, pair in enumerate(heartLine.cordList):
        if pair in edgeLine.cordList:
            #case 1 intersects with middle
            if 4<=index<7 :
                app.heartRes +="It seems you will find a fairy tale true love. "
            # case 2, intersects with peter pointer
            if 0<=index<=4: 
                app.heartRes +="You also seem to hold abundance of love, great dreams and high expectations. "
    #below middle finger, doesn't intersect with edge --> sort of straight
    if medium and pair not in edgeLine.cordList:
        app.heartRes += "You are stable, conservative, mild, affectinote, approachable. "
        app.heartRes+= "In love, you are usually shy and play a passive role. "
    if lon:
        app.heartRes += "If your heart line is without break, you could have a stable and harmonious family. "
    if heartLine.intensity == "dark":
        app.heartRes += "You are confident with your feelings and have an idea of what you like. "
    if heartLine.intensity == "light":
        app.heartRes += "It seems like you tend to doubt your feelings a lot. Practice to have faith. Things will follow through. "
    if heartLine.intensity == "ave":
        app.heartRes += "But, you can also be doutbful and less empathetic. "

def processLifeLine(app):
    try:lifeLine = app.lines[3]
    except: lifeLine = lines([], 'ave')
    try:crossLine = app.lines[4]
    except: crossLine = lines([], 'ave')
    if app.lifeNum>1:
        if lifeLine.intensity == "dark":
            app.lifeRes = "you are full of energy and resilience! Even if you have depressing moments you make sure to get back on your feet. "
        elif lifeLine.intensity == "ave":
            app.lifeRes = "you are an energetic person, but you do have instances when life gets to you. "
        elif lifeLine.intensity == "light":
            app.lifeNum = "you do have energy in you, but your environment seems to put you down these days. " 
    if lifeLine.intensity == "dark":
        app.lifeRes = "you have a healthy state of life energy. You can maintain your energy and deal with stress and not be constantly down. "
    if lifeLine.intensity == "ave":
        app.lifeRes = "you usually carry good energy but there are times when you just don't enjoy the day and feel down. Do excersice and eat healthy, as it may help build your life energy. "
    if lifeLine.intensity == "light":
        app.lifeRes = "you are not much an energetic person, but do not dwell on it. "
        app.lifeRes+= "If you bring a big change in your life and have an enviornment that understands you, it would rejuvinate your life energy. "
    #break in lifeline
    if crossLine.cordList == []: return 
    if crossLine.cordList != []:
        count = 0
        for pair in crossLine.cordList:
            if pair in lifeLine.cordList:
                count +=1
        if count >1 and crossLine.intensity == 'dark':
            app.lifeRes += "You experienced a phase in life that was too much for you. If you haven't, the universe depicts a time when you would have low state of energy overall. "
        elif count >=1 and crossLine.intensity == 'light' or 'ave':
            app.lifeRes +="You have probabilty of encountering depression."
        elif count == 0 and crossLine.intensity == 'light' or 'ave':return
            
def processType(app):
    app.type = processHandShape(app)
    if app.type == "fire": app.typeRes = "you are passionate, confident, and industrious!"
    if app.type == 'air': app.typeRes ="you are intellectually curious with an innate analytical ability and/or communication skills.You are easy to distract and, if not stimulated, can become anxious or edgy."
    if app.type == "earth": app.typeRes = 'you are practical, logical and grounded. While secure and reliable, if you get consumed with your immediate reality, it can hinder your long-term planning and achievement.'
    if app.type == 'water': app.typeRes = 'you are in tune with your emotions, intuition, and psychic ability. Fueled by compassion and imagination, you are a creative one. You tend to be quite sensitive and easily hurt, being potent to interpersonal stress.'
    if app.type not in ['fire', 'water', 'air', 'earth']:
        app.typeRes = "you are a mysterious one. You carry the essence of fire, water, air and earth. So, you reflect characteristics of all elements combined!"

def proccessHeadLine(app):
    headLine = app.lines[1]
    heartLine = app.lines[0]
    palmWidth = app.palm[0]
    try:lifeLine = app.lines[1]
    except: lifeLine = lines([], 'ave')
    try:crossLine = app.lines[4]
    except: crossLine = lines([], 'ave')
    #medium head line
    if (palmWidth.length()/2)<=headLine.length()<=2+(palmWidth.length()/2):
        app.headRes = 'smart and brilliant, with the ability to do things. '
    #long head line
    elif 0<=abs(headLine.length()-palmWidth.length())<=5:
        app.headRes = "you have a clear mind and quite a thinker (with a chance for overthinking). But you are very considerate towards others. "
    #short head line
    else: app.headRes = "you tend be slow, careless and impulsive. Nevertheless, you express yourself."
    cordheart, cordHead = heartLine.cordList, headLine.cordList
    (x1,y1), (x2, y2) = cordheart[-1], cordHead[-1]
    if ((x1-x2)== 0):gradient =2 #steep 
    else:gradient = (y2-y2)/(x2-x1)
    if gradient>1: #curved downwards
        app.headRes += " Your headlines indicates that you are highly creative and artistic and can be influenced by emotions. "
        app.headRes += " You are fit for jobs that demands creativity. "
    elif 0<gradient<=1.5: #curved 
        app.headRes += " You seem to be tolerant, realistic and have good interpersonal skills. "
    else: #straight
        app.headRes += " You are very strong mentally, practical and extremely dedicated, with great analytical ability. "
    if headLine.intensity == 'dark':
        app.headRes+= "You have faith in your thoughts. "
    elif headLine.intensity == "light":
        app.headRes += "You tend to be doubtful of your thoughts. "

def processLuckLine(app):
    count = 0
    luckLine = app.lines[2]
    palmHeight = app.palm[1]
    lifeLine = app.lines[3]
    heartLine = app.lines[0]
    #if light
    if luckLine.intensity == "light":
        app.luckRes += "you find it difficult to gain opportunities you seek. "
        app.luckRes += "This may be caused due to carelessness, or because you don't get a job you are interested in. "
    # for average color
    elif luckLine.intensity == "ave":
        app.luckRes += "your destiny demands hard work and presents a career full of twists and turns. "
    # long and dark fate line :)
    elif luckLine.intensity == 'dark': app.luckRes = "you tend to be lucky person. "
    if palmHeight.length()+2<=luckLine.length()<=palmHeight.length() and luckLine.intensity == "dark":
        app.luckRes += "you are indeed lucky! So, you have the luck and ability to start and run your own career or business. "
        app.luckRes += "And as you tend to emphasis on credibility, you can enjoy a successful career with endless strives. "
    #if short:
    if luckLine.length() < (palmHeight.length()/2):
        app.luckRes += "The world expects you to work hard and still not have mercy on you. But hard work and determination can overcome any miss fortune. "
    #if long:
    if (palmHeight.length())<=luckLine.length()<=palmHeight.length(): 
        app.luckRes += "You would find opportunity to present itself. "
        #if long and intersects with lifeLine: 
        for pair in lifeLine.cordList:
            if pair in lifeLine.cordList: 
                count +=1
        if count>3: app.luckRes += "You have a high chance to be a celebrity. "
        elif count<=3 or count>=1:app.luckRes += "You tend to attract attention. And so you would fit a celebrity-like status. "

runApp(width=1440, height=900)